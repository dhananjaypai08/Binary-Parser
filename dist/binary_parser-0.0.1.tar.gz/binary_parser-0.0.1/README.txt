A python module where a number can be converted to it's binary bits and binary bits in numbers.
Note: binary bits which will be recieved and provided will be in string format.